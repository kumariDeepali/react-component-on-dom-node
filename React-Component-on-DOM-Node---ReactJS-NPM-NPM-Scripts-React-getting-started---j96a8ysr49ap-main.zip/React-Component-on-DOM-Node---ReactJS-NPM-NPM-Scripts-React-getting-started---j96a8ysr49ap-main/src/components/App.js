
import React from "react";

const App = () =>{
  
  return (
    <p>Now I can render any React component on any DOM node I want using ReactDOM.render</p>
    )
}

export default App;



